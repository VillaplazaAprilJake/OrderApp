using System.Collections.Generic;

namespace OrderApp.Persistence
{
    // Submission item 4: FakeOrderRepository.
    // It implements the same IOrderRepository interface as the real
    // SqlOrderRepository, but keeps orders in memory instead of hitting
    // a real database. Because Form1 depends on the IOrderRepository
    // abstraction (Part 5, DIP) rather than on SqlOrderRepository
    // directly, this fake can be swapped in for btnSaveOrder_Click's
    // logic in a unit test — no database, no network, no test flakiness,
    // and the test can inspect SavedOrders afterward to assert the
    // right data was "saved".
    public class FakeOrderRepository : IOrderRepository
    {
        public List<Order> SavedOrders { get; } = new List<Order>();

        public void Save(Order order)
        {
            SavedOrders.Add(order);
        }
    }
}
