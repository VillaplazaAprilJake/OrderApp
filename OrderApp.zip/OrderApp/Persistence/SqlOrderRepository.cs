using System.Data.SqlClient;

namespace OrderApp.Persistence
{
    // Part 5 (DIP): this is the low-level detail. Form1 no longer
    // knows this class exists — it only knows about IOrderRepository.
    public class SqlOrderRepository : IOrderRepository
    {
        private readonly string _connectionString;

        public SqlOrderRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void Save(Order order)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                var cmd = new SqlCommand(
                    "INSERT INTO Orders (Email, Total) VALUES(@e, @t)", conn);
                cmd.Parameters.AddWithValue("@e", order.CustomerEmail);
                cmd.Parameters.AddWithValue("@t", order.Total);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
