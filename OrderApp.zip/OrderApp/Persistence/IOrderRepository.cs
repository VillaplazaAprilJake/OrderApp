namespace OrderApp.Persistence
{
    // Part 4 (ISP): this interface does ONE thing — save an order.
    // It is not bundled together with emailing or printing, so a class
    // that only needs to save orders (or a fake used in tests) is never
    // forced to implement methods it has no use for.
    public interface IOrderRepository
    {
        void Save(Order order);
    }
}
