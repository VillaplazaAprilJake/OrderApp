using System;
using System.Collections.Generic;
using System.Windows.Forms;
using OrderApp.Discounts;
using OrderApp.Notifications;
using OrderApp.Persistence;

namespace OrderApp
{
    public partial class Form1 : Form
    {
        // Part 5 (DIP): Form1 depends on abstractions, not concrete
        // classes. It no longer knows SqlConnection or SmtpClient exist.
        private readonly IOrderRepository _orderRepository;
        private readonly IInvoiceEmailer _invoiceEmailer;
        private readonly IInvoicePrinter _invoicePrinter;
        private readonly OrderCalculator _calculator = new OrderCalculator();
        private readonly DiscountFactory _discountFactory = new DiscountFactory();

        private decimal _total;

        // The designer/runtime uses this constructor with the real,
        // production implementations.
        public Form1() : this(
            new SqlOrderRepository("Server=localhost;Database=Orders;..."),
            new SmtpInvoiceEmailer("smtp.gmail.com", "store@shop.com"),
            new MessageBoxInvoicePrinter())
        {
        }

        // Tests (or a future console/host app) call this constructor
        // directly and pass in fakes — e.g. FakeOrderRepository —
        // without touching a real database or SMTP server.
        public Form1(IOrderRepository orderRepository, IInvoiceEmailer invoiceEmailer, IInvoicePrinter invoicePrinter)
        {
            InitializeComponent();
            _orderRepository = orderRepository;
            _invoiceEmailer = invoiceEmailer;
            _invoicePrinter = invoicePrinter;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var items = ReadItemsFromGrid();
            string discountType = cmbDiscountType.SelectedItem.ToString();
            IDiscountStrategy discount = _discountFactory.Get(discountType);

            // Part 1 (SRP): Form1 delegates the math to OrderCalculator
            // and only handles reading the grid and updating the label.
            _total = _calculator.CalculateTotal(items, discount);
            lblTotal.Text = _total.ToString("C");
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            var order = new Order { CustomerEmail = txtCustomerEmail.Text, Total = _total };
            _orderRepository.Save(order);
            MessageBox.Show("Saved!");
        }

        private void btnEmailInvoice_Click(object sender, EventArgs e)
        {
            _invoiceEmailer.SendInvoice(txtCustomerEmail.Text, _total);
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            _invoicePrinter.Print(txtCustomerEmail.Text, _total);
        }

        private List<OrderItem> ReadItemsFromGrid()
        {
            var items = new List<OrderItem>();

            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.Cells["Price"].Value == null) continue;

                items.Add(new OrderItem
                {
                    Product = row.Cells["Product"].Value?.ToString(),
                    Price = Convert.ToDecimal(row.Cells["Price"].Value),
                    Qty = Convert.ToInt32(row.Cells["Qty"].Value)
                });
            }

            return items;
        }
    }
}
