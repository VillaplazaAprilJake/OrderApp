namespace OrderApp
{
    // Part 1 (SRP): the thing that gets saved / emailed / printed.
    // Keeping this separate from OrderItem and from Form1 means every
    // downstream class (repository, emailer, printer) depends on one
    // small, stable shape instead of reaching into the form.
    public class Order
    {
        public string CustomerEmail { get; set; }
        public decimal Total { get; set; }
    }
}
