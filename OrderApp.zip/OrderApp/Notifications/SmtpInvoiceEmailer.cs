using System.Net.Mail;

namespace OrderApp.Notifications
{
    public class SmtpInvoiceEmailer : IInvoiceEmailer
    {
        private readonly string _smtpHost;
        private readonly string _fromAddress;

        public SmtpInvoiceEmailer(string smtpHost, string fromAddress)
        {
            _smtpHost = smtpHost;
            _fromAddress = fromAddress;
        }

        public void SendInvoice(string customerEmail, decimal total)
        {
            var smtp = new SmtpClient(_smtpHost);
            var mail = new MailMessage(_fromAddress, customerEmail)
            {
                Body = $"Your total is {total:C}"
            };
            smtp.Send(mail);
        }
    }
}
