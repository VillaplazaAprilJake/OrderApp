namespace OrderApp.Notifications
{
    // Part 4 (ISP): separate from IOrderRepository on purpose.
    // Saving an order and emailing an invoice are different
    // responsibilities with different reasons to change (DB schema
    // vs. SMTP provider), so they get different interfaces.
    public interface IInvoiceEmailer
    {
        void SendInvoice(string customerEmail, decimal total);
    }
}
