namespace OrderApp.Notifications
{
    // Part 4 (ISP): printing is its own tiny interface too. The starter
    // code's "print" is really just a message box, but keeping this
    // separate means swapping in a real printer later touches only
    // this one implementation.
    public interface IInvoicePrinter
    {
        void Print(string customerEmail, decimal total);
    }
}
