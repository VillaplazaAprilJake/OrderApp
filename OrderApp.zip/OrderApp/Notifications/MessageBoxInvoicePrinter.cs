using System.Windows.Forms;

namespace OrderApp.Notifications
{
    public class MessageBoxInvoicePrinter : IInvoicePrinter
    {
        public void Print(string customerEmail, decimal total)
        {
            MessageBox.Show($"Invoice for {customerEmail}: {total:C}");
        }
    }
}
