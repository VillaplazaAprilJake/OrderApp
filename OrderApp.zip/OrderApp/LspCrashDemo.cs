using System;
using OrderApp.Discounts;
using OrderApp.Persistence;

namespace OrderApp
{
    // Not wired into the form. Run this manually (e.g. from a quick
    // Console app or a test method) to produce the crash and screen
    // recording required by submission item 3, and to show the
    // FakeOrderRepository from submission item 4 in use.
    public static class LspCrashDemo
    {
        public static void RunLspCrash()
        {
            var calculator = new OrderCalculator();
            var items = new System.Collections.Generic.List<OrderItem>
            {
                new OrderItem { Product = "Widget", Price = 10m, Qty = 2 }
            };

            // Every other IDiscountStrategy (NoDiscount, StudentDiscount,
            // SeniorDiscount, BlackFridayDiscount) returns a decimal.
            // OrderCalculator.CalculateTotal has no idea this one is
            // different — and that's the point of LSP: calling code is
            // supposed to be able to treat any IDiscountStrategy the
            // same way. This line throws NotSupportedException instead.
            IDiscountStrategy broken = new FreeShippingDiscount();
            decimal total = calculator.CalculateTotal(items, broken); // <-- crashes here
            Console.WriteLine(total);
        }

        public static void RunFakeRepositoryDemo()
        {
            var fakeRepo = new FakeOrderRepository();
            var order = new Order { CustomerEmail = "student@example.com", Total = 42.00m };

            fakeRepo.Save(order);

            Console.WriteLine($"Orders saved in fake repo: {fakeRepo.SavedOrders.Count}");
            Console.WriteLine($"First saved email: {fakeRepo.SavedOrders[0].CustomerEmail}");
        }
    }
}
