namespace OrderApp.Discounts
{
    public class BlackFridayDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.7m;
    }
}
