namespace OrderApp.Discounts
{
    public class SeniorDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.85m;
    }
}
