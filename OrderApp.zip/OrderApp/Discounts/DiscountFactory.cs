using System.Collections.Generic;

namespace OrderApp.Discounts
{
    // Part 2 (OCP): a registry instead of an if/else chain.
    // Adding "Military" later means one line here, or better, moving
    // this registration out to a startup/config step — either way,
    // the classes above never change.
    public class DiscountFactory
    {
        private readonly Dictionary<string, IDiscountStrategy> _strategies =
            new Dictionary<string, IDiscountStrategy>
            {
                { "None", new NoDiscount() },
                { "Student", new StudentDiscount() },
                { "Senior", new SeniorDiscount() },
                { "BlackFriday", new BlackFridayDiscount() },
            };

        public IDiscountStrategy Get(string discountType)
        {
            return _strategies.TryGetValue(discountType, out var strategy)
                ? strategy
                : new NoDiscount();
        }
    }
}
