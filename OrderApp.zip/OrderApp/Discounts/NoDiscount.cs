namespace OrderApp.Discounts
{
    public class NoDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total;
    }
}
