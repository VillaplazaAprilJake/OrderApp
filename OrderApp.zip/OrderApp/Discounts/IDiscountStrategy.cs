namespace OrderApp.Discounts
{
    // Part 2 (OCP): every discount is now a class that implements this
    // one method. To add a new discount type, you ADD a new class —
    // you never have to open or edit an existing one.
    public interface IDiscountStrategy
    {
        decimal Apply(decimal total);
    }
}
