namespace OrderApp.Discounts
{
    public class StudentDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.9m;
    }
}
