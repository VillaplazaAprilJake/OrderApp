using System;

namespace OrderApp.Discounts
{
    // Part 3 (LSP) — DO NOT wire this into DiscountFactory.
    // This class is here only to demonstrate an LSP violation, per the
    // assignment's submission requirement #3. Any code that accepts an
    // IDiscountStrategy and calls Apply(total) — like OrderCalculator —
    // will crash the instant this implementation is substituted in,
    // because it throws instead of returning a decimal like every
    // other IDiscountStrategy promises to.
    public class FreeShippingDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total)
        {
            throw new NotSupportedException("Doesn't apply to order totals, only shipping!");
        }
    }
}
