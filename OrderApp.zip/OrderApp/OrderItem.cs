namespace OrderApp
{
    // Part 1 (SRP): a plain data holder for one row of the grid.
    // Pulling this out means OrderCalculator never has to know about
    // DataGridViewRow or anything WinForms-specific.
    public class OrderItem
    {
        public string Product { get; set; }
        public decimal Price { get; set; }
        public int Qty { get; set; }
    }
}
