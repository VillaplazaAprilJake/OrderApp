using System.Collections.Generic;
using OrderApp.Discounts;

namespace OrderApp
{
    // Part 1 (SRP): the ONLY job of this class is arithmetic.
    // It knows nothing about buttons, grids, databases, or email —
    // so it can be unit tested with a plain list of OrderItem and
    // a discount strategy, no WinForms project required.
    public class OrderCalculator
    {
        public decimal CalculateTotal(IEnumerable<OrderItem> items, IDiscountStrategy discount)
        {
            decimal total = 0;

            foreach (var item in items)
            {
                total += item.Price * item.Qty;
            }

            return discount.Apply(total);
        }
    }
}
