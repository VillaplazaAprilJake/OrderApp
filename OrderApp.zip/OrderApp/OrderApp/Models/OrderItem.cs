namespace OrderApp.Models
{
    /// <summary>
    /// A single line item in an order (one row of the items grid).
    /// </summary>
    public class OrderItem
    {
        public string Product { get; set; }
        public decimal Price { get; set; }
        public int Qty { get; set; }

        public decimal LineTotal => Price * Qty;
    }
}
