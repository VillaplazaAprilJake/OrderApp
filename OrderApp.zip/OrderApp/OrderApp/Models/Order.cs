using System.Collections.Generic;

namespace OrderApp.Models
{
    /// <summary>
    /// A completed order: who it's for, what was bought, and the final total
    /// (after any discount has already been applied).
    /// </summary>
    public class Order
    {
        public string CustomerEmail { get; set; }
        public List<OrderItem> Items { get; set; } = new List<OrderItem>();
        public decimal Total { get; set; }
    }
}
