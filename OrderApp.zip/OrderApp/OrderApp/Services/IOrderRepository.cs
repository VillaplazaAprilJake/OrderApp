using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>Persists a finished order somewhere.</summary>
    public interface IOrderRepository
    {
        void Save(Order order);
    }
}
