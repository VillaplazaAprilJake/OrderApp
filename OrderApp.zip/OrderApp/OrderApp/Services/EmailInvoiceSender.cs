using System.Net.Mail;
using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>Emails the customer their invoice via SMTP.</summary>
    public class EmailInvoiceSender : IInvoiceSender
    {
        private readonly string _smtpHost;
        private readonly string _fromAddress;

        public EmailInvoiceSender(string smtpHost = "smtp.gmail.com", string fromAddress = "store@shop.com")
        {
            _smtpHost = smtpHost;
            _fromAddress = fromAddress;
        }

        public void Send(Order order)
        {
            var smtp = new SmtpClient(_smtpHost);
            var mail = new MailMessage(_fromAddress, order.CustomerEmail)
            {
                Subject = "Your invoice",
                Body = $"Your total is {order.Total:C}"
            };
            smtp.Send(mail);
        }
    }
}
