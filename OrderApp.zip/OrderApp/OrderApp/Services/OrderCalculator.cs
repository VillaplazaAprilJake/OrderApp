using System.Collections.Generic;
using System.Linq;
using OrderApp.Discounts;
using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>
    /// Its one job is pricing: sum the line items, then hand the subtotal to
    /// whatever IDiscountStrategy it's given. It doesn't know about SQL,
    /// email, or the UI.
    /// </summary>
    public class OrderCalculator
    {
        public decimal CalculateTotal(IEnumerable<OrderItem> items, IDiscountStrategy discount)
        {
            decimal subtotal = items.Sum(i => i.LineTotal);
            return discount.Apply(subtotal);
        }
    }
}
