using System.Collections.Generic;
using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>
    /// PART 5 - an in-memory stand-in for SqlOrderRepository.
    ///
    /// It's useful for testing because it lets us verify Form1's save
    /// logic (does it build the right Order, does it call Save exactly
    /// once, etc.) without a real database connection - so tests stay
    /// fast, run anywhere, and never leave leftover rows behind.
    /// </summary>
    public class FakeOrderRepository : IOrderRepository
    {
        public List<Order> SavedOrders { get; } = new List<Order>();

        public void Save(Order order)
        {
            SavedOrders.Add(order);
        }
    }
}
