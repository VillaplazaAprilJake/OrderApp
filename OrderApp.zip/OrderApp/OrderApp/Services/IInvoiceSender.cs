using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>Delivers an invoice for a completed order.</summary>
    public interface IInvoiceSender
    {
        void Send(Order order);
    }
}
