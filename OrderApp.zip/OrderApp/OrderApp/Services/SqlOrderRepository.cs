using System.Data.SqlClient;
using OrderApp.Models;

namespace OrderApp.Services
{
    /// <summary>Saves orders to the Orders table in SQL Server.</summary>
    public class SqlOrderRepository : IOrderRepository
    {
        private readonly string _connectionString;

        public SqlOrderRepository(string connectionString = "Server=localhost;Database=Orders;Trusted_Connection=True;")
        {
            _connectionString = connectionString;
        }

        public void Save(Order order)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand("INSERT INTO Orders (Email, Total) VALUES(@e, @t)", conn))
                {
                    cmd.Parameters.AddWithValue("@e", order.CustomerEmail);
                    cmd.Parameters.AddWithValue("@t", order.Total);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
