using System;

namespace OrderApp.Discounts
{
    /// <summary>
    /// PART 3 DEMO - INTENTIONAL LSP VIOLATION.
    ///
    /// This class is kept in the project on purpose so the crash can be
    /// reproduced and (per the assignment) screen-recorded. It implements
    /// IDiscountStrategy but refuses to do the one thing every
    /// IDiscountStrategy promises to do: turn a total into a discounted
    /// total. See README.md ("Part 3") for the explanation of why this
    /// breaks Liskov Substitution.
    /// </summary>
    public class FreeShippingDiscount : IDiscountStrategy
    {
        public decimal Apply(decimal total)
        {
            throw new NotSupportedException("Doesn't apply to order totals, only shipping!");
        }
    }
}
