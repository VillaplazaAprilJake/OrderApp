namespace OrderApp.Discounts
{
    /// <summary>15% off for seniors.</summary>
    public class SeniorDiscountStrategy : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.85m;
    }
}
