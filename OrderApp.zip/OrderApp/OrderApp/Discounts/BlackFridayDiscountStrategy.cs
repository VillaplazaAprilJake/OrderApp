namespace OrderApp.Discounts
{
    /// <summary>30% off during the Black Friday promotion.</summary>
    public class BlackFridayDiscountStrategy : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.7m;
    }
}
