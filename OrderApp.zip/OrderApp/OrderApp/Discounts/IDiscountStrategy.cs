namespace OrderApp.Discounts
{
    /// <summary>
    /// A rule that turns a pre-discount total into a post-discount total.
    ///
    /// LSP CONTRACT: any implementation must accept any non-negative decimal
    /// order total and return a discounted decimal order total. It must not
    /// throw for a well-formed total, and it must not do anything other than
    /// compute a price (no side effects). Callers such as OrderCalculator are
    /// written against this contract and are allowed to assume every
    /// IDiscountStrategy honors it - that is exactly what makes the
    /// strategies substitutable for one another.
    /// </summary>
    public interface IDiscountStrategy
    {
        decimal Apply(decimal total);
    }
}
