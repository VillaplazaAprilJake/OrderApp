namespace OrderApp.Discounts
{
    /// <summary>Applies no discount at all - the identity case.</summary>
    public class NoDiscountStrategy : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total;
    }
}
