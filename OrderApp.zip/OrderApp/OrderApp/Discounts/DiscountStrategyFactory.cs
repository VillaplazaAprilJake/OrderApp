using System.Collections.Generic;

namespace OrderApp.Discounts
{
    /// <summary>
    /// Looks up an IDiscountStrategy by the text shown in cmbDiscountType.
    /// OrderCalculator and Form1 never branch on discount names - only this
    /// factory does, and adding a new discount type means adding one line
    /// here plus a new class, not editing existing logic.
    /// </summary>
    public class DiscountStrategyFactory
    {
        private readonly Dictionary<string, IDiscountStrategy> _strategies =
            new Dictionary<string, IDiscountStrategy>
            {
                { "None", new NoDiscountStrategy() },
                { "Student", new StudentDiscountStrategy() },
                { "Senior", new SeniorDiscountStrategy() },
                { "BlackFriday", new BlackFridayDiscountStrategy() },

                // PART 3 DEMO ONLY - see README "Part 3". Registering this
                // here is what makes the crash reachable from the running
                // app (pick "FreeShipping" in the combo box, click Calculate).
                { "FreeShipping", new FreeShippingDiscount() },
            };

        public IDiscountStrategy GetStrategy(string name)
        {
            string key = (name ?? string.Empty).Trim();
            return _strategies.TryGetValue(key, out var strategy)
                ? strategy
                : new NoDiscountStrategy();
        }
    }
}
