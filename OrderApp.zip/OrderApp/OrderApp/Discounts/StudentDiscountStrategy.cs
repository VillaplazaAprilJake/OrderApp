namespace OrderApp.Discounts
{
    /// <summary>10% off for students.</summary>
    public class StudentDiscountStrategy : IDiscountStrategy
    {
        public decimal Apply(decimal total) => total * 0.9m;
    }
}
