﻿using System;
using System.Windows.Forms;
using OrderApp.Discounts;
using OrderApp.Models;
using OrderApp.Services;

namespace OrderApp
{
    public partial class Form1 : Form
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IInvoiceSender _invoiceSender;
        private readonly OrderCalculator _calculator = new OrderCalculator();
        private readonly DiscountStrategyFactory _discountFactory = new DiscountStrategyFactory();

        private decimal _total;

        // Parameterless constructor kept for the WinForms Designer and as
        // the app's normal entry point. It wires up the real, concrete
        // services. This is the one place that decides "SQL + SMTP" -
        // everything else in the form only ever talks to the interfaces.
        public Form1() : this(new SqlOrderRepository(), new EmailInvoiceSender())
        {
        }

        // DIP: Form1 depends on IOrderRepository / IInvoiceSender, not on
        // SqlConnection or SmtpClient directly. Tests (or a future console
        // app) can pass in FakeOrderRepository / a fake sender instead.
        public Form1(IOrderRepository orderRepository, IInvoiceSender invoiceSender)
        {
            InitializeComponent();
            _orderRepository = orderRepository;
            _invoiceSender = invoiceSender;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var items = ReadItemsFromGrid();
            var discount = _discountFactory.GetStrategy(cmbDiscountType.SelectedItem?.ToString());

            _total = _calculator.CalculateTotal(items, discount);
            lblTotal.Text = _total.ToString("C");
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            var order = BuildOrder();
            _orderRepository.Save(order);
            MessageBox.Show("Saved!");
        }

        private void btnEmailInvoice_Click(object sender, EventArgs e)
        {
            var order = BuildOrder();
            _invoiceSender.Send(order);
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Invoice for {txtCustomerEmail.Text}: {_total:C}");
        }

        private System.Collections.Generic.List<OrderItem> ReadItemsFromGrid()
        {
            var items = new System.Collections.Generic.List<OrderItem>();
            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.Cells["Price"].Value == null) continue;

                items.Add(new OrderItem
                {
                    Product = row.Cells["Product"].Value?.ToString(),
                    Price = Convert.ToDecimal(row.Cells["Price"].Value),
                    Qty = Convert.ToInt32(row.Cells["QTY"].Value)
                });
            }
            return items;
        }

        private Order BuildOrder()
        {
            return new Order
            {
                CustomerEmail = txtCustomerEmail.Text,
                Items = ReadItemsFromGrid(),
                Total = _total
            };
        }
    }
}
