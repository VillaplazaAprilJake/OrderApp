# OrderApp - SOLID Refactor

So the original form1.cs is have much work inside the button-click methods. 
bali sha po ang nag handled tanan ata. murag nag isa sila si isa ka place,
lisud siya usbon. and need pag actual database og email server.

**Single Responsibility Principle (SRP).** then ang Form1 is para nalang sa pagkuha sa input sa UI ug pag-handle sa mga button clicks.
Ang computation sa presyo kay gibutang sa OrderCalculator,
ang pag-save sa order naa sa IOrderRepository,
ug ang pag-send sa email naa sa IInvoiceSender.

**Open/Closed Principle (OCP).** ang discount kay gipili gamit og if/else sample if (discount == "Student").
. if naay bag o nga promotion need pa usbon ang nag exist pa nga code.
IDiscountStrategy, and DiscountStrategyFactory mao ni nagbuot karun kung unsa nga discount ang gamiton. sample Adding "FreeShipping" meant writing a new class and one
dictionary entry - OrderCalculator and Form1 di sha change.

**Liskov Substitution Principle (LSP).**  this is the one
the assignment asks us to break on purpose to show why it matters.

**Interface Segregation Principle (ISP).** combine sa pricing, database, ug email.
IDiscountStrategy - para sa discount
IOrderRepository - para sa pag-save sa order
IInvoiceSender - para sa pag-send sa email

**Dependency Inversion Principle (DIP).**ang Form1 mismo ang nag-create sa SqlConnection ug SmtpClient.
 gina directly connected siya sa SQL Server ug email server.
so ang Form1 nag depend nalang sa IOrderRepository ug IInvoiceSender. 

## Part 3 - the LSP violation
example for breaking sa LSP. the program is expecting nga tanan IDiscountStrategy makahatag og discounted total, pero ang FreeShippingDiscount dili makabuhat ana.
Mao nga mo-crash ang application.So thats why importante ang LSP kay kung ang class nag-implement sa usa ka interface, dapat kaya niya sundon ang expected behavior sa interface.

## Part 5 - FakeOrderRepository
Useful ni para sa mga testing kay dili na kinahanglan mag connect sa real SQL Server. 
Pwede sd ma check if sakto ba ang Form1 sa paghimo ug pag save sa Order.
pwede mag test bisan walay internet or database.
